<!DOCTYPE html>
<html>
    <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <title>Lab01 Scripts</title>

    </head>
<body>
    <?php 
    echo "<h1>Sample output for all three scripts</h1>";
    echo "<h2>Question 01</h2>";
    echo "<p>Hello World</p>";
    
    ?>
</body>


</html>