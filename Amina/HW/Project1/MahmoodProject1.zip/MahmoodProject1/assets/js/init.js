// initialize necessary materialize components
(function($){
    $(function(){
        $('input#input_text, textarea#textarea2').characterCounter();
        $('select').formSelect();
    });
})(jQuery);