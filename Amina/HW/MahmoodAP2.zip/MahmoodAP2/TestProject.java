
import MahmoodAP2.*;

public class TestProject {

public static void main(String[] args) {
   CompanyServices cs = new CompanyServices();
   
   //System.out.println(cs.deleteAllCompanies("axm6392").getEntity());
   //System.out.println(cs.getDepartment("axm6392",1).getEntity());
   //System.out.println(cs.getCompanyDepartments("axm6392").getEntity());
   //System.out.println(cs.insertCompanyDepartment("axm6392","software developer", "d61", "rochester").getEntity());
   //System.out.println(cs.updateDepartment("{\"company\":\"axm6392\", \"dept_id\":\"5\",\"dept_name\":\"IT\", \"location\":\"rochester\"}").getEntity());
   //System.out.println(cs.updateDepartment("{\"company\":\"axm6392\", \"dept_id\":\"5\",\"dept_name\":\"IT\", \"dept_no\":\"d57\", \"location\":\"rochester\"}").getEntity());
  
   //System.out.println(cs.getEmployee("axm6392",1).getEntity());
   //System.out.println(cs.getCompanyEmployees("axm6392").getEntity());
   //System.out.println(cs.insertEmployee("axm6392", "French", "rituserid-e61", "2018-06-13", "programmer", 5000.0, 1, 2).getEntity());
   //System.out.println(cs.updateEmployee("{\"emp_id\":1, \"company\":\"axm6392\", \"emp_name\":\"french\",\"emp_no\":\"rituserid-e1b\",\"hire_date\":\"2018-06-16\", \"job\":\"programmer\", \"salary\":5000.0, \"dept_id\":1, \"mng_id\":2}").getEntity());
   //System.out.println(cs.deleteEmployee("axm6392",16).getEntity());
   

   //System.out.println(cs.getTimecard("axm6392",2).getEntity());
   //System.out.println(cs.getEmployeeTimecards("axm6392", 3).getEntity());
   //System.out.println(cs.insertTimecard("axm6392", 1, "2019-11-20 10:00:00", "2019-11-20 12:30:00", 3).getEntity());
   //System.out.println(cs.updateTimecard("{\"company\":\"axm6392\", \"timecard_id\":3, \"start_time\":\"2018-06-14 11:30:00\", \"end_time\":\"2018-06-14 15:30:00\", \"emp_id\":2}").getEntity());
   //System.out.println(cs.deleteTimecard("axm6392", 1).getEntity());
}
}